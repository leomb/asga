<div>
	<?php the_content(); ?>
</div>
