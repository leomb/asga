<div class="col-xs-12 col-lg-3 sidebar">
	<?php if (is_active_sidebar('sidebar1')) : ?>
		<?php dynamic_sidebar('sidebar1'); ?>
	<?php endif; ?>
</div>
